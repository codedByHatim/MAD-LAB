export const surahNames = [
    { english: "Al-Fatiha", arabic: "الفاتحة" },
    { english: "Al-Baqarah", arabic: "البقرة" },
    { english: "Al-Imran", arabic: "آل عمران" },
   
  ];
  
  export const surahDetails = [
    { 
        number: 1,
        name: { english: "Al-Fatiha", arabic: "الفاتحة" },
        revelationType: "Meccan",
        totalAyahs: 7,
        startPage: 1
    },
    { 
        number: 2,
        name: { english: "Al-Baqarah", arabic: "البقرة" },
        revelationType: "Medinan",
        totalAyahs: 286,
        startPage: 2
    },
    { 
        number: 3,
        name: { english: "Al-Imran", arabic: "آل عمران" },
        revelationType: "Medinan",
        totalAyahs: 200,
        startPage: 50
    },
    
  ];
  

