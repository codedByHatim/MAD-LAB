import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, Switch, StyleSheet } from 'react-native';
import { surahNames, surahDetails } from './QuranData';

const App = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [darkMode, setDarkMode] = useState(false);
  const filteredSurahs = surahDetails.filter(surah => 
    surah.name.english.toLowerCase().includes(searchQuery.toLowerCase()) ||
    surah.name.arabic.includes(searchQuery)
  );

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <View style={[styles.container, darkMode && styles.darkContainer]}>
      <View style={styles.header}>
        <Text style={styles.title}>Quran App</Text>
        <Switch
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={darkMode ? "#f5dd4b" : "#f4f3f4"}
          ios_backgroundColor="#3e3e3e"
          onValueChange={toggleDarkMode}
          value={darkMode}
        />
      </View>
      <TextInput
        style={[styles.input, darkMode && styles.darkInput]}
        placeholder="Search Surah..."
        value={searchQuery}
        onChangeText={text => setSearchQuery(text)}
      />
      <FlatList
        data={filteredSurahs}
        renderItem={({ item }) => (
          <TouchableOpacity style={[styles.surahCard, darkMode && styles.darkSurahCard]}>
            <Text style={styles.surahName}>{item.name.english} - {item.name.arabic}</Text>
            <Text style={styles.surahDetails}>Revelation Type: {item.revelationType}</Text>
            <Text style={styles.surahDetails}>Total Ayahs: {item.totalAyahs}</Text>
            <Text style={styles.surahDetails}>Start Page: {item.startPage}</Text>
          </TouchableOpacity>
        )}
        keyExtractor={item => item.number.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 10,
  },
  darkContainer: {
    backgroundColor: '#333',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
  },
  darkInput: {
    backgroundColor: '#444',
    color: '#fff',
  },
  surahCard: {
    padding: 10,
    backgroundColor: '#f9f9f9',
    marginBottom: 10,
    borderRadius: 5,
  },
  darkSurahCard: {
    backgroundColor: '#444',
  },
  surahName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  surahDetails: {
    fontSize: 14,
  },
});

export default App;
